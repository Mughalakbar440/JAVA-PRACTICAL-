package employeeData;

public class DemoEmp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EmployeeData ed = new EmployeeData();
		ed.setName("Pooja");
		ed.setDesignation("manager");
		ed.setBasicSalary(345668);
		
		
		System.out.println(ed);
	}

}
